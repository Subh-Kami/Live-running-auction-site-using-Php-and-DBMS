<?php

namespace App\Exceptions;

use Exception;

/**
 * Class ClassException
 * @package App\Exception
 */
class ClassException extends Exception {

	/**
	 * Constructor of class
	 * @param string    $message  The Exception message to throw.
	 * @param int       $code     [optional] The Exception code.
	 * @param Exception $previous [optional] The previous throwable used for the exception chaining.
	 */
	public function __construct($message, $code = 0, Exception $previous = null) {
		parent::__construct($message, $code, $previous);
	}

	/**
	 * String representation of the exception
	 * @return string the string representation of the exception.
	 */
	public function __toString() {
		return __CLASS__ . ": [{$this->code}]: {$this->message}\n";
	}
}