<?php

define("DB_HOST", "localhost");
define("DB_USER", "xyz");
define("DB_PASSWORD", "xyz");
define("DB_NAME", "xyz");


define("CONFIG_ADMIN", "xyz");
define("CONFIG_ADMINEMAIL", "xyz");
define("CONFIG_URL", "xyz");
define("CONFIG_AUCTIONNAME", "Web Guys Online Auction");
define("CONFIG_CURRENCY", "$");

date_default_timezone_set("America/Toronto");

define("LOG_LOCATION", __DIR__ . "/../../logs/app.log");

define("FILE_UPLOADLOC", "imgs/");

// PayPal settings
// PayPal OAuth Credentials
define("CLIENT_ID", "xyz");
define("CLIENT_SECRET", "xyz");
define("WEBHOOK_ID", "xyz");
define("PAYPAL_CURRENCY", "CAD");
define("PAYPAL_RETURNURL", CONFIG_URL . "/payment-successful.php");
define("PAYPAL_CANCELURL", CONFIG_URL . '/payment-cancelled.php');
