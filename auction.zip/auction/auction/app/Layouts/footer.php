<p>&copy;
	<a href='mailto:"<?php echo CONFIG_ADMINEMAIL ?>"'>
		<?php echo CONFIG_ADMIN ?>
	</a>
</p>
</div>
</div>


</body>
</html>