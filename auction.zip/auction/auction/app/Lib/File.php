<?php
namespace App\Lib;

use App\Exceptions\FileException;

/**
 * Class File
 * @package App\Lib
 */
class File {
	use Helper;

	const MAXFILESIZE = 3000000;

	protected $name;
	protected $type;
	protected $size;
	protected $tmp_name;
	protected $error;

	/**
	 * Deletes a file from the server
	 * @param string $destLoc
	 * @return bool
	 * @throws FileException
	 */
	public static function deleteFile(string $destLoc): bool {
		if(!file_exists($destLoc))
			throw new FileException("File does not exist");
		return unlink($destLoc);
	}

	/**
	 * File constructor.
	 * @param $file
	 */
	public function __construct($file) {
		foreach($_FILES["$file"] as $key => $value) {
			$this->$key = $value;
		}
	}

	/**
	 * Renames the file to its original name and move it
	 * @return bool
	 * @throws FileException
	 */
	public function moveUploadedFile(): bool {
		if(file_exists(FILE_UPLOADLOC . $this->name))
			throw new FileException("File already exists");
		$result = move_uploaded_file($this->tmp_name, FILE_UPLOADLOC . $this->name);
		if(!$result) throw new FileException("Cannot move file");
		return $result;
	}

} //End of File Class