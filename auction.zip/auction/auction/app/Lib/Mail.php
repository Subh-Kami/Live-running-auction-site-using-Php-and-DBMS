<?php
namespace App\Lib;

use App\Exceptions\MailException;

class Mail {
    public static function sendMail(string $to, string $subject, string $body): bool {
        // Create headers
        $headers = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

        // Use the PHP mail function
        $result = mail($to, $subject, $body, $headers);

        // Check if the mail operation failed and throw an exception if needed
        if (!$result) {
            throw new MailException("Internal Error: Cannot send mail");
        }

        return $result;
    }
}
?>
