<?php

namespace App\Models;

use App\Exceptions\ClassException;
use App\Lib\Model;
use App\Exceptions\MailException;
use App\Lib\Logger;
use App\Lib\Mail;

/**
 * Class User
 * @package App\Models
 */
class User extends Model {
	protected static $table_name = "users";

	public static $errorArray = array(
		"pass"        => "Passwords do not match!",
		"taken"       => "Username taken, please use another.",
		"no"          => "Incorrect login details!",
		"failedlogin" => "Incorrect login, please try again!",
		"notverified" => "This account is not verified yet. You were emailed a link to verify the account. Please click on the link in the email to continue."
	);

	protected $id = 0;
	protected $username;
	protected $password;
	protected $email;
	protected $verify = "";
	protected $active = 0;

	/**
	 * User constructor.
	 * @param $username
	 * @param $password
	 * @param $email
	 */
	public function __construct($username, $password, $email) {
		$this->username = $username;
		$this->password = password_hash($password ?? "", PASSWORD_BCRYPT, ['cost' => 10]);
		$this->email = $email;
        $this->verify = $this->randStr();
	}

	/**
	 * Attempt user login. If success, return a user object.
	 * @param string $email
	 * @param string $password
	 * @return bool|User
	 */
	public static function auth(string $email, string $password) {
		try {
			//Add code below to call findFirst with condition username is equal to $username
			$user = self::findFirst(["email" => $email]);
			if(password_verify($password, $user->get('password')))
				return $user;
		} catch(ClassException $e) {
		}
		return false;
	}

    private function randStr(): string {
        return substr(md5(rand()), 0, 16);
    }

    public function mailUser(): bool {
        $verifystring = urlencode($this->verify);
        $email = urlencode($this->email);
        $url = CONFIG_URL;
        $mail_body = <<< _MAIL_
Hi $this->username,

Please click on the following link to verify your new account:
<a href="{$url}/verify.php?email=$email&verify=$verifystring">Click here</a>

_MAIL_;

        try {
            $subject = CONFIG_AUCTIONNAME . " user verification";
            $result = Mail::sendMail($this->email, $subject, $mail_body);

            if ($result) {
                return true;
            } else {
                Logger::getLogger()->error("Email sending failed for user: $this->username");
                return false;
            }
        } catch (MailException $e) {
            Logger::getLogger()->critical("Could not send mail: ", ['exception' => $e]);
            return false;
        }
    }

} //End of User Class